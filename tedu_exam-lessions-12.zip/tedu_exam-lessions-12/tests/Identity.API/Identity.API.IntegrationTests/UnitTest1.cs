using System;
using Xunit;

namespace Identity.API.IntegrationTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
