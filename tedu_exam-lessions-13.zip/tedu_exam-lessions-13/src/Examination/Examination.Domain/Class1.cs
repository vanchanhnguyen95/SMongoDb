﻿using System;

namespace Examination.Domain
{
    public class Class1
    {
    }
}
