﻿using System;

namespace Examination.Infrastructure
{
    public class Class1
    {
    }
}
