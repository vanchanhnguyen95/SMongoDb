using System;
using Xunit;

namespace Examination.API.IntegrationTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
