﻿using System;

namespace Examination.Application
{
    public class Class1
    {
    }
}
